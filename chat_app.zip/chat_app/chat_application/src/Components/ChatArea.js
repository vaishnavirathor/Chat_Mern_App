import { IconButton } from '@mui/material'
import React,{useState} from 'react'
import DeleteIcon from '@mui/icons-material/Delete';
import ArrowForwardIcon from '@mui/icons-material/ArrowForward';import MessageSelf from './MessageSelf';
import MessageOther from './MessageOther';

function ChatArea() {
  const [conversations,setConversations]=useState([
    {
        name:"Test#1",
        lastMessage:"Last Message #1",
        timeStamp:"today",
    },
    {
        name:"Test#2",
        lastMessage:"Last Message #1",
        timeStamp:"today",
    },
    {
        name:"Test#3",
        lastMessage:"Last Message #1",
        timeStamp:"today",
    },


]);
var props=conversations[0];
  return (
    <div className='chatArea-container'>
    <div className="ChatArea-Header">
    <div className="header-text">
        <p className="con-title">{props.name}</p>
        <p className="con-timeStamp">{props.timeStamp}</p>
    </div>
    <IconButton>
    <DeleteIcon/>
    </IconButton>
    </div>
    <div className="messages-container">
      <MessageOther/>
      <MessageSelf/>
    </div>
    <div className="text-input-area">
    <input placeholder='search' className='search-box'/>
    <IconButton>
      <ArrowForwardIcon/>
    </IconButton>
    </div>
    </div>
  )
}

export default ChatArea
