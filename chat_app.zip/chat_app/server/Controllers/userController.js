const express=require("express");
const UserModel =require('./userModel');
const expressAsyncHandler=require("express-async-handler");

const loginController=()=>{};
const registerController=expressAsyncHandler ( async(req,res)=>{
    const{name,email,password}= req.body;
   if(!name || !email ||!password)
    {
        req.send(400);
        throw Error("All necessary input required")
    }

    const UserExist= await UserModel.findOne({email});
    if(UserExist)
        {
            throw new Error("User Already Exists");
        }

   const UserNameExist= await UserModel.findOne({name});
    if(UserNameExist)
        {
            throw new Error("Username Already Exists");
        }

        // create entry
        const user=UserExist.create({name , email,password });
});




   