const express = require("express");
const dotenv = require("dotenv");
const mongoose = require('mongoose');
const userRoutes=require('./Routes/userRoutes');

const app = express();
dotenv.config();

mongoose.connect(process.env.MONGO_URI);

const connectDb=async()=>{
    try{
        const connect=await mongoose.connect(process.env.MONGO_URI);
        console.log("connected to db");
    }
    catch(err){
        console.log("not conneced to db")
    }
}
connectDb();
  
app.get("/", (req, res) => {
  res.send({ msg: "Hello World 1293" });
});
app.use("user/",userRoutes);

app.listen(5009, () => {
    console.log(`Server is running on port 5009 `);
  });